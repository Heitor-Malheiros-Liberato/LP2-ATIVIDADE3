﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Diagnostics;
using System.Drawing;
using System.Globalization;
using System.Linq;
using System.Runtime.Remoting.Channels;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp1
{
    public partial class Form1 : Form
    {
        double[] valores = new double[3];
        public Form1()
        {
            InitializeComponent();
        }

        private void ValNumber(object sender, CancelEventArgs e)
        {
             try
            {
                if (sender.Equals(txtBoxV1))
                {
                    errorV.SetError(txtBoxV1, "");
                }
                if (sender.Equals(txtBoxV2))
                {
                    errorV.SetError(txtBoxV2, "");
                }
                if (sender.Equals(txtBoxV3))
                {
                    errorV.SetError(txtBoxV3, "");
                }

                if (sender.Equals(txtBoxV1))
                {
                    valores[0] = Convert.ToDouble(txtBoxV1.Text);
                }
                if (sender.Equals(txtBoxV2))
                {
                    valores[1] = Convert.ToDouble(txtBoxV2.Text);
                }
                if (sender.Equals(txtBoxV3))
                {
                    valores[2] = Convert.ToDouble(txtBoxV3.Text);
                }
            }
            catch
            {
                if (sender.Equals(txtBoxV1))
                {
                    errorV.SetError(txtBoxV1, "1º Valor inválido");
                }
                if (sender.Equals(txtBoxV2))
                {
                    errorV.SetError(txtBoxV2, "2º Valor inválido");
                }
                if (sender.Equals(txtBoxV3))
                {
                    errorV.SetError(txtBoxV3, "3º Valor inválido");
                }
            }
        }

        private void btnVerificar_Click(object sender, EventArgs e)
        {
            if (valores[0] < valores[1] + valores[2]
                &&
                valores[0] > Math.Abs(valores[1] - valores[2])
                &&
                valores[1] < valores[0] + valores[2]
                &&
                valores[1] > Math.Abs(valores[0] - valores[2])
                &&
                valores[2] < valores[0] + valores[1]
                &&
                valores[2] > Math.Abs(valores[0] - valores[1]))
            {
                ptrBoxTriangulos.Visible = true;
                if (valores[0] == valores[1] && valores[1] == valores[2])
                    MessageBox.Show("É um triângulo Equilátero");
                else if (valores[0] == valores[1] || valores[1] == valores[2])
                    MessageBox.Show("É um triângulo Isósceles");
                else
                    MessageBox.Show("É um triângulo Escaleno");
            }
            else
                MessageBox.Show("Não é um triângulo");
        }

        private void btnLimpar_Click(object sender, EventArgs e)
        {
            txtBoxV1.Clear();
            txtBoxV2.Clear();
            txtBoxV3.Clear();
        }

        private void btnSair_Click(object sender, EventArgs e)
        {
            Close();
        }
    }
}
