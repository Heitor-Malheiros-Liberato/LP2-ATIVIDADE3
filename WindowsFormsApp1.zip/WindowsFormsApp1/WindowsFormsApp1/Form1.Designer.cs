﻿namespace WindowsFormsApp1
{
    partial class Form1
    {
        /// <summary>
        /// Variável de designer necessária.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Limpar os recursos que estão sendo usados.
        /// </summary>
        /// <param name="disposing">true se for necessário descartar os recursos gerenciados; caso contrário, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código gerado pelo Windows Form Designer

        /// <summary>
        /// Método necessário para suporte ao Designer - não modifique 
        /// o conteúdo deste método com o editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.btnVerificar = new System.Windows.Forms.Button();
            this.txtBoxV1 = new System.Windows.Forms.TextBox();
            this.lblV1 = new System.Windows.Forms.Label();
            this.lblV2 = new System.Windows.Forms.Label();
            this.txtBoxV2 = new System.Windows.Forms.TextBox();
            this.lblV3 = new System.Windows.Forms.Label();
            this.txtBoxV3 = new System.Windows.Forms.TextBox();
            this.btnLimpar = new System.Windows.Forms.Button();
            this.btnSair = new System.Windows.Forms.Button();
            this.errorV = new System.Windows.Forms.ErrorProvider(this.components);
            this.ptrBoxTriangulos = new System.Windows.Forms.PictureBox();
            ((System.ComponentModel.ISupportInitialize)(this.errorV)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.ptrBoxTriangulos)).BeginInit();
            this.SuspendLayout();
            // 
            // btnVerificar
            // 
            this.btnVerificar.Location = new System.Drawing.Point(555, 199);
            this.btnVerificar.Name = "btnVerificar";
            this.btnVerificar.Size = new System.Drawing.Size(82, 31);
            this.btnVerificar.TabIndex = 0;
            this.btnVerificar.Text = "Verificar";
            this.btnVerificar.UseVisualStyleBackColor = true;
            this.btnVerificar.Click += new System.EventHandler(this.btnVerificar_Click);
            // 
            // txtBoxV1
            // 
            this.txtBoxV1.Location = new System.Drawing.Point(537, 55);
            this.txtBoxV1.Name = "txtBoxV1";
            this.txtBoxV1.Size = new System.Drawing.Size(100, 26);
            this.txtBoxV1.TabIndex = 1;
            this.txtBoxV1.Validating += new System.ComponentModel.CancelEventHandler(this.ValNumber);
            // 
            // lblV1
            // 
            this.lblV1.AutoSize = true;
            this.lblV1.Location = new System.Drawing.Point(443, 58);
            this.lblV1.Name = "lblV1";
            this.lblV1.Size = new System.Drawing.Size(78, 20);
            this.lblV1.TabIndex = 2;
            this.lblV1.Text = "1º Vartice";
            // 
            // lblV2
            // 
            this.lblV2.AutoSize = true;
            this.lblV2.Location = new System.Drawing.Point(443, 90);
            this.lblV2.Name = "lblV2";
            this.lblV2.Size = new System.Drawing.Size(78, 20);
            this.lblV2.TabIndex = 4;
            this.lblV2.Text = "2º Vertice";
            // 
            // txtBoxV2
            // 
            this.txtBoxV2.Location = new System.Drawing.Point(537, 87);
            this.txtBoxV2.Name = "txtBoxV2";
            this.txtBoxV2.Size = new System.Drawing.Size(100, 26);
            this.txtBoxV2.TabIndex = 3;
            this.txtBoxV2.Validating += new System.ComponentModel.CancelEventHandler(this.ValNumber);
            // 
            // lblV3
            // 
            this.lblV3.AutoSize = true;
            this.lblV3.Location = new System.Drawing.Point(443, 122);
            this.lblV3.Name = "lblV3";
            this.lblV3.Size = new System.Drawing.Size(78, 20);
            this.lblV3.TabIndex = 6;
            this.lblV3.Text = "3º Vartice";
            // 
            // txtBoxV3
            // 
            this.txtBoxV3.Location = new System.Drawing.Point(537, 119);
            this.txtBoxV3.Name = "txtBoxV3";
            this.txtBoxV3.Size = new System.Drawing.Size(100, 26);
            this.txtBoxV3.TabIndex = 5;
            this.txtBoxV3.Validating += new System.ComponentModel.CancelEventHandler(this.ValNumber);
            // 
            // btnLimpar
            // 
            this.btnLimpar.Location = new System.Drawing.Point(439, 199);
            this.btnLimpar.Name = "btnLimpar";
            this.btnLimpar.Size = new System.Drawing.Size(82, 31);
            this.btnLimpar.TabIndex = 7;
            this.btnLimpar.Text = "Limpar";
            this.btnLimpar.UseVisualStyleBackColor = true;
            this.btnLimpar.Click += new System.EventHandler(this.btnLimpar_Click);
            // 
            // btnSair
            // 
            this.btnSair.Location = new System.Drawing.Point(496, 236);
            this.btnSair.Name = "btnSair";
            this.btnSair.Size = new System.Drawing.Size(82, 31);
            this.btnSair.TabIndex = 8;
            this.btnSair.Text = "Sair";
            this.btnSair.UseVisualStyleBackColor = true;
            this.btnSair.Click += new System.EventHandler(this.btnSair_Click);
            // 
            // errorV
            // 
            this.errorV.ContainerControl = this;
            // 
            // ptrBoxTriangulos
            // 
            this.ptrBoxTriangulos.Image = global::WindowsFormsApp1.Properties.Resources.tipos_de_triangulos_de_acordo_com_seus_lados_30679_0_6001;
            this.ptrBoxTriangulos.Location = new System.Drawing.Point(276, 275);
            this.ptrBoxTriangulos.Name = "ptrBoxTriangulos";
            this.ptrBoxTriangulos.Size = new System.Drawing.Size(552, 250);
            this.ptrBoxTriangulos.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.ptrBoxTriangulos.TabIndex = 9;
            this.ptrBoxTriangulos.TabStop = false;
            this.ptrBoxTriangulos.Visible = false;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1125, 537);
            this.Controls.Add(this.ptrBoxTriangulos);
            this.Controls.Add(this.btnSair);
            this.Controls.Add(this.btnLimpar);
            this.Controls.Add(this.lblV3);
            this.Controls.Add(this.txtBoxV3);
            this.Controls.Add(this.lblV2);
            this.Controls.Add(this.txtBoxV2);
            this.Controls.Add(this.lblV1);
            this.Controls.Add(this.txtBoxV1);
            this.Controls.Add(this.btnVerificar);
            this.Name = "Form1";
            this.Text = "Form1";
            ((System.ComponentModel.ISupportInitialize)(this.errorV)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.ptrBoxTriangulos)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button btnVerificar;
        private System.Windows.Forms.TextBox txtBoxV1;
        private System.Windows.Forms.Label lblV1;
        private System.Windows.Forms.Label lblV2;
        private System.Windows.Forms.TextBox txtBoxV2;
        private System.Windows.Forms.Label lblV3;
        private System.Windows.Forms.TextBox txtBoxV3;
        private System.Windows.Forms.Button btnLimpar;
        private System.Windows.Forms.Button btnSair;
        private System.Windows.Forms.ErrorProvider errorV;
        private System.Windows.Forms.PictureBox ptrBoxTriangulos;
    }
}

